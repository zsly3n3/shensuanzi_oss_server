package datastruct

// 请填写您的AccessKeyId。
const AccessKeyId = "LTAIrI5VLxul4WVs"

// 请填写您的AccessKeySecret。
const AccessKeySecret = "90tKumbwoLaRJID8rRdTcwSPfCAAlS"

// host的格式为 bucketname.endpoint ，请替换为您的真实信息。
const Host = "https://shensuanzi.oss-cn-shenzhen.aliyuncs.com"

const Release_ipAndport = ":9627"
const Debug_ipAndport = ":9267"
const Debug_callbackUrl = "https://apptx.yequandaka.com/shensuanzi_dev_callback"
const Release_callbackUrl = "https://apptx.yequandaka.com/shensuanzi_release_callback"
